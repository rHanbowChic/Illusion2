# -*- coding: utf-8 -*-
€ = 2
